import sys,os
pid_parameter=dict()